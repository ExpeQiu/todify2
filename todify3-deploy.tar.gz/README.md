# My Python Project

This is a simple Python project.

## How to Run

To run the main script, execute:
```bash
python main.py
```

## How to Test

To run the tests, execute:
```bash
pytest test_main.py
```
