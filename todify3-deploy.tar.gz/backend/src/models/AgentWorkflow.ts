import { DatabaseManager } from '../config/database';

// ==================== 类型定义 ====================

/**
 * Agent工作流节点
 */
export interface AgentWorkflowNode {
  id: string;
  type: string;
  agentId: string;
  position: {
    x: number;
    y: number;
  };
  data: {
    label: string;
    agentName?: string;
    inputs?: Record<string, any>;
    outputs?: string[];
  };
}

/**
 * Agent工作流连接边
 */
export interface AgentWorkflowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
  condition?: string; // JSON字符串
  animated?: boolean;
  label?: string;
  style?: string; // JSON字符串
}

/**
 * Agent工作流
 */
export interface AgentWorkflow {
  id: string;
  name: string;
  description?: string;
  version: string;
  nodes: string; // JSON字符串
  edges: string; // JSON字符串
  metadata?: string; // JSON字符串
  published?: number; // 0或1，是否已发布（只有发布的工作流才能被前端页面绑定）
  created_at?: string;
  updated_at?: string;
}

/**
 * 工作流执行实例（统一表结构，支持Agent工作流和Dify工作流）
 */
export interface WorkflowExecution {
  id: string;
  execution_type: 'agent_workflow' | 'dify_workflow';
  
  // Agent工作流字段
  workflow_id?: string;
  workflow_name?: string;
  shared_context?: string; // JSON字符串
  node_results?: string; // JSON字符串
  
  // Dify工作流字段
  workflow_run_id?: string;
  task_id?: string;
  message_id?: string;
  app_type?: string;
  
  // 通用字段
  status: string;
  error_message?: string;
  inputs?: string; // JSON字符串
  outputs?: string; // JSON字符串
  elapsed_time?: number;
  total_tokens?: number;
  total_steps?: number;
  duration?: number;
  
  // 时间戳
  start_time?: string;
  end_time?: string;
  started_at?: string;
  finished_at?: string;
  created_at?: string;
  updated_at?: string;
}

/**
 * 工作流模板
 */
export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  thumbnail?: string;
  workflow_structure: string; // JSON字符串
  metadata?: string; // JSON字符串
  is_public?: boolean;
  usage_count?: number;
  created_at?: string;
  updated_at?: string;
}

/**
 * DTO接口
 */
export interface CreateAgentWorkflowDTO {
  id?: string;
  name: string;
  description?: string;
  version?: string;
  nodes: AgentWorkflowNode[];
  edges: AgentWorkflowEdge[];
  metadata?: Record<string, any>;
}

export interface UpdateAgentWorkflowDTO {
  name?: string;
  description?: string;
  version?: string;
  nodes?: AgentWorkflowNode[];
  edges?: AgentWorkflowEdge[];
  metadata?: Record<string, any>;
  published?: boolean;
}

export interface CreateWorkflowExecutionDTO {
  id?: string;
  execution_type: 'agent_workflow' | 'dify_workflow';
  
  // Agent工作流字段
  workflow_id?: string;
  workflow_name?: string;
  shared_context?: Record<string, any>;
  node_results?: any[];
  
  // Dify工作流字段
  workflow_run_id?: string;
  task_id?: string;
  message_id?: string;
  app_type?: string;
  
  // 通用字段
  status?: string;
  error_message?: string;
  inputs?: Record<string, any>;
  outputs?: Record<string, any>;
  elapsed_time?: number;
  total_tokens?: number;
  total_steps?: number;
  duration?: number;
  
  // 时间戳
  start_time?: string;
  end_time?: string;
  started_at?: string;
  finished_at?: string;
  metadata?: Record<string, any>;
}

export interface CreateWorkflowTemplateDTO {
  id?: string;
  name: string;
  description: string;
  category: string;
  thumbnail?: string;
  workflow_structure: any;
  metadata?: Record<string, any>;
  is_public?: boolean;
}

// ==================== 模型类 ====================

/**
 * Agent工作流模型
 */
export class AgentWorkflowModel {
  private db: DatabaseManager;

  constructor(db: DatabaseManager) {
    this.db = db;
  }

  /**
   * 确保数据库连接
   */
  private async ensureConnection(): Promise<void> {
    if (!this.db) {
      throw new Error('数据库管理器未初始化');
    }
    await this.db.connect();
  }

  /**
   * 初始化数据库表
   */
  async initializeTable(): Promise<void> {
    await this.ensureConnection();
    
    // 直接执行CREATE TABLE语句（避免文件系统依赖）
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS agent_workflows (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        version TEXT NOT NULL DEFAULT '1.0.0',
        nodes TEXT NOT NULL,
        edges TEXT NOT NULL,
        metadata TEXT,
        published INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    
    try {
      await this.db.query(createTableSQL);
      
      // 尝试添加 published 字段（如果表已存在且字段不存在）
      try {
        await this.db.query('ALTER TABLE agent_workflows ADD COLUMN published INTEGER DEFAULT 0');
      } catch (error: any) {
        // 忽略字段已存在的错误
        if (!error.message?.includes('duplicate column') && !error.message?.includes('already exists')) {
          console.warn('添加 published 字段时出现警告:', error.message);
        }
      }
    } catch (error: any) {
      // 忽略"表已存在"等错误
      if (!error.message?.includes('already exists') && !error.message?.includes('duplicate')) {
        console.warn('创建agent_workflows表时出现警告:', error.message);
      }
    }
    
    // 创建工作流执行表（统一结构，支持Agent工作流和Dify工作流）
    // 注意：如果表已存在（通过迁移脚本创建），此CREATE TABLE IF NOT EXISTS不会修改现有结构
    const createExecutionTableSQL = `
      CREATE TABLE IF NOT EXISTS workflow_executions (
        id TEXT PRIMARY KEY,
        execution_type TEXT NOT NULL CHECK (execution_type IN ('agent_workflow', 'dify_workflow')),
        
        -- Agent工作流执行字段
        workflow_id TEXT,
        workflow_name TEXT,
        shared_context TEXT DEFAULT '{}',
        node_results TEXT DEFAULT '[]',
        
        -- Dify工作流执行字段
        workflow_run_id TEXT UNIQUE,
        task_id TEXT,
        message_id TEXT,
        app_type TEXT,
        
        -- 通用执行字段
        status TEXT NOT NULL DEFAULT 'pending',
        error_message TEXT,
        inputs TEXT,
        outputs TEXT,
        
        -- 执行统计
        elapsed_time REAL DEFAULT 0,
        total_tokens INTEGER DEFAULT 0,
        total_steps INTEGER DEFAULT 0,
        duration INTEGER,
        
        -- 时间戳
        start_time TIMESTAMP,
        end_time TIMESTAMP,
        started_at DATETIME,
        finished_at DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        
        FOREIGN KEY (workflow_id) REFERENCES agent_workflows(id) ON DELETE SET NULL,
        FOREIGN KEY (message_id) REFERENCES chat_messages(message_id) ON DELETE SET NULL
      );
    `;
    
    try {
      await this.db.query(createExecutionTableSQL);
    } catch (error: any) {
      if (!error.message?.includes('already exists') && !error.message?.includes('duplicate')) {
        console.warn('创建workflow_executions表时出现警告:', error.message);
      }
    }

    // 如果表已存在但缺少新字段，尝试添加（向后兼容）
    const columnMigrations = [
      {
        sql: "ALTER TABLE workflow_executions ADD COLUMN execution_type TEXT CHECK (execution_type IN ('agent_workflow', 'dify_workflow'))",
        name: 'execution_type',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN workflow_run_id TEXT UNIQUE',
        name: 'workflow_run_id',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN task_id TEXT',
        name: 'task_id',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN message_id TEXT',
        name: 'message_id',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN app_type TEXT',
        name: 'app_type',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN error_message TEXT',
        name: 'error_message',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN inputs TEXT',
        name: 'inputs',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN outputs TEXT',
        name: 'outputs',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN elapsed_time REAL DEFAULT 0',
        name: 'elapsed_time',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN total_tokens INTEGER DEFAULT 0',
        name: 'total_tokens',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN total_steps INTEGER DEFAULT 0',
        name: 'total_steps',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN started_at DATETIME',
        name: 'started_at',
      },
      {
        sql: 'ALTER TABLE workflow_executions ADD COLUMN finished_at DATETIME',
        name: 'finished_at',
      },
    ];

    for (const migration of columnMigrations) {
      try {
        await this.db.query(migration.sql);
      } catch (error: any) {
        const message: string | undefined = error?.message;
        if (
          !message ||
          (!message.includes('duplicate column') && !message.includes('already exists') && !message.includes('UNIQUE'))
        ) {
          console.warn(`添加 workflow_executions.${migration.name} 字段时出现警告:`, message || error);
        }
      }
    }

    // 如果execution_type为空，为现有记录设置默认值（假设都是agent_workflow）
    try {
      await this.db.query(
        `UPDATE workflow_executions 
         SET execution_type = 'agent_workflow'
         WHERE execution_type IS NULL`
      );
    } catch (error: any) {
      console.warn('更新 workflow_executions execution_type 默认值时出现警告:', error?.message || error);
    }
    
    // 创建工作流模板表
    const createTemplateTableSQL = `
      CREATE TABLE IF NOT EXISTS workflow_templates (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        thumbnail TEXT,
        workflow_structure TEXT NOT NULL,
        metadata TEXT,
        is_public INTEGER DEFAULT 0,
        usage_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    
    try {
      await this.db.query(createTemplateTableSQL);
    } catch (error: any) {
      if (!error.message?.includes('already exists') && !error.message?.includes('duplicate')) {
        console.warn('创建workflow_templates表时出现警告:', error.message);
      }
    }
    
    // 创建索引
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_agent_workflows_name ON agent_workflows(name);',
      'CREATE INDEX IF NOT EXISTS idx_agent_workflows_updated ON agent_workflows(updated_at DESC);',
      'CREATE INDEX IF NOT EXISTS idx_workflow_executions_workflow_id ON workflow_executions(workflow_id);',
      'CREATE INDEX IF NOT EXISTS idx_workflow_executions_status ON workflow_executions(status);',
      'CREATE INDEX IF NOT EXISTS idx_workflow_templates_category ON workflow_templates(category);',
    ];
    
    for (const indexSQL of indexes) {
      try {
        await this.db.query(indexSQL);
      } catch (error: any) {
        // 忽略索引已存在的错误
        if (!error.message?.includes('already exists') && !error.message?.includes('duplicate')) {
          console.warn('创建索引时出现警告:', error.message);
        }
      }
    }
  }

  /**
   * 创建Agent工作流
   */
  async create(data: CreateAgentWorkflowDTO): Promise<AgentWorkflow> {
    await this.ensureConnection();

    const id = data.id || `wf_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const version = data.version || '1.0.0';

    const sql = `
      INSERT INTO agent_workflows (
        id, name, description, version, nodes, edges, metadata, published, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `;

    const params = [
      id,
      data.name,
      data.description || null,
      version,
      JSON.stringify(data.nodes),
      JSON.stringify(data.edges),
      data.metadata ? JSON.stringify(data.metadata) : null,
      (data as any).published ? 1 : 0,
    ];

    await this.db.query(sql, params);

    return await this.getById(id) as AgentWorkflow;
  }

  /**
   * 根据ID获取工作流
   */
  async getById(id: string): Promise<AgentWorkflow | null> {
    await this.ensureConnection();

    const sql = 'SELECT * FROM agent_workflows WHERE id = ?';
    const result = await this.db.query(sql, [id]);
    const rows = Array.isArray(result) ? result : result.rows || [result];

    if (rows.length === 0) {
      return null;
    }

    const row = rows[0];
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      version: row.version,
      nodes: row.nodes,
      edges: row.edges,
      metadata: row.metadata,
      published: row.published !== undefined ? row.published : 0,
      created_at: row.created_at,
      updated_at: row.updated_at,
    };
  }

  /**
   * 获取所有工作流
   */
  async getAll(): Promise<AgentWorkflow[]> {
    try {
      await this.ensureConnection();

      // 先检查表是否存在
      const checkTableSql = `
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='agent_workflows'
      `;
      const tableCheck = await this.db.query(checkTableSql);
      const hasTable = Array.isArray(tableCheck) 
        ? tableCheck.length > 0 
        : (tableCheck as any)?.rows?.length > 0 || !!tableCheck;

      if (!hasTable) {
        console.warn('⚠️  agent_workflows表不存在，返回空数组');
        return [];
      }

      const sql = 'SELECT * FROM agent_workflows ORDER BY updated_at DESC';
      const result = await this.db.query(sql);
      const rows = Array.isArray(result) ? result : result.rows || [];

      return rows.map((row: any) => ({
        id: row.id,
        name: row.name,
        description: row.description,
        version: row.version,
        nodes: row.nodes,
        edges: row.edges,
        metadata: row.metadata,
        published: row.published !== undefined ? row.published : 0,
        created_at: row.created_at,
        updated_at: row.updated_at,
      }));
    } catch (error) {
      // 如果表不存在或查询失败，返回空数组而不是抛出错误
      console.error('⚠️  获取工作流列表失败，返回空数组:', error instanceof Error ? error.message : String(error));
      return [];
    }
  }

  /**
   * 更新工作流
   */
  async update(id: string, data: UpdateAgentWorkflowDTO): Promise<AgentWorkflow> {
    await this.ensureConnection();

    // 获取现有工作流
    const existing = await this.getById(id);
    if (!existing) {
      throw new Error(`工作流不存在: ${id}`);
    }

    const sql = `
      UPDATE agent_workflows SET
        name = ?,
        description = ?,
        version = ?,
        nodes = ?,
        edges = ?,
        metadata = ?,
        published = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    const params = [
      data.name ?? existing.name,
      data.description !== undefined ? data.description : existing.description,
      data.version || existing.version,
      data.nodes ? JSON.stringify(data.nodes) : existing.nodes,
      data.edges ? JSON.stringify(data.edges) : existing.edges,
      data.metadata ? JSON.stringify(data.metadata) : existing.metadata,
      data.published !== undefined ? (data.published ? 1 : 0) : (existing.published !== undefined ? existing.published : 0),
      id,
    ];

    await this.db.query(sql, params);

    return await this.getById(id) as AgentWorkflow;
  }

  /**
   * 删除工作流
   */
  async delete(id: string): Promise<boolean> {
    await this.ensureConnection();

    const sql = 'DELETE FROM agent_workflows WHERE id = ?';
    const result: any = await this.db.query(sql, [id]);

    return (result.changes && result.changes > 0) || false;
  }

  /**
   * 搜索工作流
   */
  async search(query: string): Promise<AgentWorkflow[]> {
    await this.ensureConnection();

    const sql = `
      SELECT * FROM agent_workflows
      WHERE name LIKE ? OR description LIKE ?
      ORDER BY updated_at DESC
    `;

    const searchPattern = `%${query}%`;
    const result = await this.db.query(sql, [searchPattern, searchPattern]);
    const rows = Array.isArray(result) ? result : result.rows || [];

    return rows.map((row: any) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      version: row.version,
      nodes: row.nodes,
      edges: row.edges,
      metadata: row.metadata,
      published: row.published !== undefined ? row.published : 0,
      created_at: row.created_at,
      updated_at: row.updated_at,
    }));
  }
}

/**
 * 工作流执行模型
 */
export class WorkflowExecutionModel {
  private db: DatabaseManager;

  constructor(db: DatabaseManager) {
    this.db = db;
  }

  private async ensureConnection(): Promise<void> {
    if (!this.db) {
      throw new Error('数据库管理器未初始化');
    }
    await this.db.connect();
  }

  /**
   * 创建执行实例（支持Agent工作流和Dify工作流）
   */
  async create(data: CreateWorkflowExecutionDTO): Promise<WorkflowExecution> {
    await this.ensureConnection();

    const id = data.id || `exec_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const status = data.status || 'pending';
    const executionType = data.execution_type;

    const sql = `
      INSERT INTO workflow_executions (
        id, execution_type, workflow_id, workflow_name, shared_context, node_results,
        workflow_run_id, task_id, message_id, app_type,
        status, error_message, inputs, outputs,
        elapsed_time, total_tokens, total_steps, duration,
        start_time, end_time, started_at, finished_at,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `;

    const params = [
      id,
      executionType,
      // Agent工作流字段
      data.workflow_id || null,
      data.workflow_name || null,
      data.shared_context ? JSON.stringify(data.shared_context) : null,
      data.node_results ? JSON.stringify(data.node_results) : null,
      // Dify工作流字段
      data.workflow_run_id || null,
      data.task_id || null,
      data.message_id || null,
      data.app_type || null,
      // 通用字段
      status,
      data.error_message || null,
      data.inputs ? JSON.stringify(data.inputs) : null,
      data.outputs ? JSON.stringify(data.outputs) : null,
      data.elapsed_time || null,
      data.total_tokens || null,
      data.total_steps || null,
      data.duration || null,
      // 时间戳
      data.start_time || null,
      data.end_time || null,
      data.started_at || null,
      data.finished_at || null,
    ];

    await this.db.query(sql, params);

    return await this.getById(id) as WorkflowExecution;
  }

  /**
   * 根据ID获取执行实例
   */
  async getById(id: string): Promise<WorkflowExecution | null> {
    await this.ensureConnection();

    const sql = 'SELECT * FROM workflow_executions WHERE id = ?';
    const result = await this.db.query(sql, [id]);
    const rows = Array.isArray(result) ? result : result.rows || [result];

    if (rows.length === 0) {
      return null;
    }

    const row = rows[0];
    return {
      id: row.id,
      execution_type: row.execution_type,
      // Agent工作流字段
      workflow_id: row.workflow_id,
      workflow_name: row.workflow_name,
      shared_context: row.shared_context,
      node_results: row.node_results,
      // Dify工作流字段
      workflow_run_id: row.workflow_run_id,
      task_id: row.task_id,
      message_id: row.message_id,
      app_type: row.app_type,
      // 通用字段
      status: row.status,
      error_message: row.error_message,
      inputs: row.inputs,
      outputs: row.outputs,
      elapsed_time: row.elapsed_time,
      total_tokens: row.total_tokens,
      total_steps: row.total_steps,
      duration: row.duration,
      // 时间戳
      start_time: row.start_time,
      end_time: row.end_time,
      started_at: row.started_at,
      finished_at: row.finished_at,
      created_at: row.created_at,
      updated_at: row.updated_at,
    };
  }

  /**
   * 根据工作流ID获取所有执行实例
   */
  async getByWorkflowId(workflowId: string): Promise<WorkflowExecution[]> {
    await this.ensureConnection();

    const sql = 'SELECT * FROM workflow_executions WHERE workflow_id = ? ORDER BY created_at DESC';
    const result = await this.db.query(sql, [workflowId]);
    const rows = Array.isArray(result) ? result : result.rows || [];

    return rows.map((row: any) => ({
      id: row.id,
      execution_type: row.execution_type,
      // Agent工作流字段
      workflow_id: row.workflow_id,
      workflow_name: row.workflow_name,
      shared_context: row.shared_context,
      node_results: row.node_results,
      // Dify工作流字段
      workflow_run_id: row.workflow_run_id,
      task_id: row.task_id,
      message_id: row.message_id,
      app_type: row.app_type,
      // 通用字段
      status: row.status,
      error_message: row.error_message,
      inputs: row.inputs,
      outputs: row.outputs,
      elapsed_time: row.elapsed_time,
      total_tokens: row.total_tokens,
      total_steps: row.total_steps,
      duration: row.duration,
      // 时间戳
      start_time: row.start_time,
      end_time: row.end_time,
      started_at: row.started_at,
      finished_at: row.finished_at,
      created_at: row.created_at,
      updated_at: row.updated_at,
    }));
  }

  /**
   * 更新执行实例
   */
  async update(id: string, updates: Partial<WorkflowExecution>): Promise<WorkflowExecution> {
    await this.ensureConnection();

    const existing = await this.getById(id);
    if (!existing) {
      throw new Error(`执行实例不存在: ${id}`);
    }

    // 构建动态更新SQL
    const updateFields: string[] = [];
    const params: any[] = [];

    if (updates.status !== undefined) {
      updateFields.push('status = ?');
      params.push(updates.status);
    }
    if (updates.shared_context !== undefined) {
      updateFields.push('shared_context = ?');
      params.push(updates.shared_context ? JSON.stringify(updates.shared_context) : null);
    }
    if (updates.node_results !== undefined) {
      updateFields.push('node_results = ?');
      params.push(updates.node_results ? JSON.stringify(updates.node_results) : null);
    }
    if (updates.workflow_run_id !== undefined) {
      updateFields.push('workflow_run_id = ?');
      params.push(updates.workflow_run_id);
    }
    if (updates.task_id !== undefined) {
      updateFields.push('task_id = ?');
      params.push(updates.task_id);
    }
    if (updates.message_id !== undefined) {
      updateFields.push('message_id = ?');
      params.push(updates.message_id);
    }
    if (updates.app_type !== undefined) {
      updateFields.push('app_type = ?');
      params.push(updates.app_type);
    }
    if (updates.error_message !== undefined) {
      updateFields.push('error_message = ?');
      params.push(updates.error_message);
    }
    if (updates.inputs !== undefined) {
      updateFields.push('inputs = ?');
      params.push(updates.inputs ? JSON.stringify(updates.inputs) : null);
    }
    if (updates.outputs !== undefined) {
      updateFields.push('outputs = ?');
      params.push(updates.outputs ? JSON.stringify(updates.outputs) : null);
    }
    if (updates.elapsed_time !== undefined) {
      updateFields.push('elapsed_time = ?');
      params.push(updates.elapsed_time);
    }
    if (updates.total_tokens !== undefined) {
      updateFields.push('total_tokens = ?');
      params.push(updates.total_tokens);
    }
    if (updates.total_steps !== undefined) {
      updateFields.push('total_steps = ?');
      params.push(updates.total_steps);
    }
    if (updates.duration !== undefined) {
      updateFields.push('duration = ?');
      params.push(updates.duration);
    }
    if (updates.start_time !== undefined) {
      updateFields.push('start_time = ?');
      params.push(updates.start_time);
    }
    if (updates.end_time !== undefined) {
      updateFields.push('end_time = ?');
      params.push(updates.end_time);
    }
    if (updates.started_at !== undefined) {
      updateFields.push('started_at = ?');
      params.push(updates.started_at);
    }
    if (updates.finished_at !== undefined) {
      updateFields.push('finished_at = ?');
      params.push(updates.finished_at);
    }

    if (updateFields.length === 0) {
      return existing;
    }

    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    params.push(id);

    const sql = `
      UPDATE workflow_executions SET
        ${updateFields.join(', ')}
      WHERE id = ?
    `;

    await this.db.query(sql, params);

    return await this.getById(id) as WorkflowExecution;
  }
}

/**
 * 工作流模板模型
 */
export class WorkflowTemplateModel {
  private db: DatabaseManager;

  constructor(db: DatabaseManager) {
    this.db = db;
  }

  private async ensureConnection(): Promise<void> {
    if (!this.db) {
      throw new Error('数据库管理器未初始化');
    }
    await this.db.connect();
  }

  /**
   * 创建模板
   */
  async create(data: CreateWorkflowTemplateDTO): Promise<WorkflowTemplate> {
    await this.ensureConnection();

    // 确保表存在
    try {
      const checkTableSql = `
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='workflow_templates'
      `;
      const tableCheck = await this.db.query(checkTableSql);
      const hasTable = Array.isArray(tableCheck) 
        ? tableCheck.length > 0 
        : (tableCheck as any)?.rows?.length > 0 || !!tableCheck;

      if (!hasTable) {
        // 如果表不存在，尝试创建
        const createTableSQL = `
          CREATE TABLE IF NOT EXISTS workflow_templates (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            thumbnail TEXT,
            workflow_structure TEXT NOT NULL,
            metadata TEXT,
            is_public INTEGER DEFAULT 0,
            usage_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          );
        `;
        await this.db.query(createTableSQL);
      }
    } catch (error: any) {
      console.warn('检查或创建 workflow_templates 表时出现警告:', error.message);
    }

    const id = data.id || `tpl_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    try {
      // 确保 workflow_structure 可以被序列化
      let workflowStructureStr: string;
      try {
        console.log('验证 workflow_structure:', {
          hasWorkflowStructure: !!data.workflow_structure,
          type: typeof data.workflow_structure,
          isArray: Array.isArray(data.workflow_structure),
          keys: data.workflow_structure && typeof data.workflow_structure === 'object' ? Object.keys(data.workflow_structure) : null,
          value: data.workflow_structure ? JSON.stringify(data.workflow_structure).substring(0, 200) : null,
        });

        if (!data.workflow_structure) {
          console.error('workflow_structure 为空或未定义');
          throw new Error('工作流结构不能为空');
        }

        // 如果已经是字符串，验证它是否是有效的 JSON
        if (typeof data.workflow_structure === 'string') {
          try {
            const parsed = JSON.parse(data.workflow_structure);
            // 验证解析后的对象包含必要的字段
            if (!parsed || typeof parsed !== 'object') {
              throw new Error('工作流结构必须是有效的对象');
            }
            if (!parsed.nodes || !Array.isArray(parsed.nodes)) {
              throw new Error('工作流结构必须包含 nodes 数组');
            }
            workflowStructureStr = data.workflow_structure;
          } catch (parseError) {
            console.error('JSON 解析失败:', parseError);
            throw new Error(`工作流结构 JSON 格式无效: ${parseError instanceof Error ? parseError.message : String(parseError)}`);
          }
        } else {
          // 如果是对象，先验证结构
          if (!data.workflow_structure || typeof data.workflow_structure !== 'object') {
            console.error('workflow_structure 不是有效对象:', typeof data.workflow_structure);
            throw new Error('工作流结构必须是有效的对象');
          }

          // 验证必要字段
          if (!data.workflow_structure.nodes || !Array.isArray(data.workflow_structure.nodes)) {
            console.error('缺少 nodes 字段或不是数组:', {
              hasNodes: !!data.workflow_structure.nodes,
              nodesType: typeof data.workflow_structure.nodes,
              isArray: Array.isArray(data.workflow_structure.nodes),
            });
            throw new Error('工作流结构必须包含 nodes 数组');
          }

          if (!data.workflow_structure.edges || !Array.isArray(data.workflow_structure.edges)) {
            console.error('缺少 edges 字段或不是数组:', {
              hasEdges: !!data.workflow_structure.edges,
              edgesType: typeof data.workflow_structure.edges,
              isArray: Array.isArray(data.workflow_structure.edges),
            });
            throw new Error('工作流结构必须包含 edges 数组');
          }

          // 序列化为 JSON
          const stringified = JSON.stringify(data.workflow_structure);
          console.log('序列化结果:', {
            length: stringified.length,
            preview: stringified.substring(0, 100),
            isEmpty: !stringified || stringified === 'null' || stringified === 'undefined' || stringified === '{}',
          });

          if (!stringified || stringified === 'null' || stringified === 'undefined' || stringified === '{}') {
            throw new Error('工作流结构序列化后为空');
          }
          workflowStructureStr = stringified;
        }

        // 最终验证：确保字符串不为空
        if (!workflowStructureStr || workflowStructureStr.trim() === '') {
          console.error('最终验证失败: workflowStructureStr 为空');
          throw new Error('工作流结构不能为空');
        }

        console.log('workflow_structure 验证通过，长度:', workflowStructureStr.length);
      } catch (error) {
        console.error('工作流结构验证失败:', error);
        throw new Error(`工作流结构序列化失败: ${error instanceof Error ? error.message : String(error)}`);
      }

      // 确保 metadata 可以被序列化
      let metadataStr: string | null = null;
      if (data.metadata) {
        try {
          metadataStr = typeof data.metadata === 'string' 
            ? data.metadata 
            : JSON.stringify(data.metadata);
        } catch (error) {
          console.warn('元数据序列化失败，将使用空值:', error);
          metadataStr = null;
        }
      }

      const sql = `
        INSERT INTO workflow_templates (
          id, name, description, category, thumbnail, workflow_structure,
          metadata, is_public, usage_count, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `;

      const params = [
        id,
        data.name,
        data.description,
        data.category,
        data.thumbnail || null,
        workflowStructureStr,
        metadataStr,
        data.is_public ? 1 : 0,
      ];

      console.log('准备插入模板数据:', {
        id,
        name: data.name,
        description: data.description,
        category: data.category,
        workflowStructureLength: workflowStructureStr.length,
        workflowStructurePreview: workflowStructureStr.substring(0, 100),
        metadataStr: metadataStr ? metadataStr.substring(0, 50) : null,
        isPublic: data.is_public ? 1 : 0,
      });

      await this.db.query(sql, params);

      console.log('模板插入成功，ID:', id);

      // 获取刚创建的模板
      const createdTemplate = await this.getById(id);
      if (!createdTemplate) {
        throw new Error(`模板创建后无法查询到，ID: ${id}`);
      }

      console.log('模板查询成功:', createdTemplate.id);

      return createdTemplate;
    } catch (error: any) {
      console.error('创建模板失败:', error);
      throw new Error(`创建模板失败: ${error.message || String(error)}`);
    }
  }

  /**
   * 根据ID获取模板
   */
  async getById(id: string): Promise<WorkflowTemplate | null> {
    await this.ensureConnection();

    const sql = 'SELECT * FROM workflow_templates WHERE id = ?';
    const result = await this.db.query(sql, [id]);
    const rows = Array.isArray(result) ? result : result.rows || [result];

    if (rows.length === 0) {
      return null;
    }

    const row = rows[0];
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      thumbnail: row.thumbnail,
      workflow_structure: row.workflow_structure,
      metadata: row.metadata,
      is_public: row.is_public === 1,
      usage_count: row.usage_count || 0,
      created_at: row.created_at,
      updated_at: row.updated_at,
    };
  }

  /**
   * 获取所有模板
   */
  async getAll(category?: string): Promise<WorkflowTemplate[]> {
    await this.ensureConnection();

    let sql = 'SELECT * FROM workflow_templates WHERE 1=1';
    const params: any[] = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    sql += ' ORDER BY usage_count DESC, updated_at DESC';

    const result = await this.db.query(sql, params);
    const rows = Array.isArray(result) ? result : result.rows || [];

    return rows.map((row: any) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      thumbnail: row.thumbnail,
      workflow_structure: row.workflow_structure,
      metadata: row.metadata,
      is_public: row.is_public === 1,
      usage_count: row.usage_count || 0,
      created_at: row.created_at,
      updated_at: row.updated_at,
    }));
  }

  /**
   * 增加使用次数
   */
  async incrementUsage(id: string): Promise<void> {
    await this.ensureConnection();

    const sql = 'UPDATE workflow_templates SET usage_count = usage_count + 1 WHERE id = ?';
    await this.db.query(sql, [id]);
  }

  /**
   * 删除模板
   */
  async delete(id: string): Promise<boolean> {
    await this.ensureConnection();

    const sql = 'DELETE FROM workflow_templates WHERE id = ?';
    const result: any = await this.db.query(sql, [id]);

    return (result.changes && result.changes > 0) || false;
  }
}

