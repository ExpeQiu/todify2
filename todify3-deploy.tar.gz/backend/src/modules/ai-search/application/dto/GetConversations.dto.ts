export interface ConversationSummaryView {
  id: string;
  title: string;
  sources: any[];
  messages: any[];
  createdAt: Date;
  updatedAt: Date;
}

