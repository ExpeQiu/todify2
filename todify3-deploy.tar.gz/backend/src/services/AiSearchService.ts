import { db } from '../config/database';
import { v4 as uuidv4 } from 'uuid';
import { FieldMappingConfig as FieldMappingConfigType } from '../types/aiSearch';
import { logger } from '@/shared/lib/logger';

export interface ConversationRecord {
  id: string;
  title: string;
  sources: string; // JSON string
  page_type?: string;
  created_at: string;
  updated_at: string;
}

export interface MessageRecord {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: string; // JSON string
  outputs?: string; // JSON string
  created_at: string;
}

export interface OutputContentRecord {
  id: string;
  type: 'ppt' | 'script' | 'mindmap' | 'other';
  title: string;
  content: string; // JSON string
  message_id: string;
  conversation_id: string;
  page_type?: string;
  created_at: string;
}

/**
 * AI问答服务
 */
export class AiSearchService {
  /**
   * 初始化数据库表
   */
  async initializeTables(): Promise<void> {
    try {
      // 创建AI问答对话表
      await db.query(`
        CREATE TABLE IF NOT EXISTS ai_search_conversations (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          sources TEXT NOT NULL,
          page_type TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);
      
      // 如果表已存在但没有 page_type 字段，添加该字段
      try {
        await db.query(`ALTER TABLE ai_search_conversations ADD COLUMN page_type TEXT`);
      } catch (error: any) {
        // 如果字段已存在，忽略错误
        if (!error?.message?.includes('duplicate column') && !error?.message?.includes('already exists')) {
          logger.warn('添加 page_type 字段失败（可能已存在）', { error });
        }
      }

      // 创建AI问答消息表
      await db.query(`
        CREATE TABLE IF NOT EXISTS ai_search_messages (
          id TEXT PRIMARY KEY,
          conversation_id TEXT NOT NULL,
          role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
          content TEXT NOT NULL,
          sources TEXT,
          outputs TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (conversation_id) REFERENCES ai_search_conversations(id) ON DELETE CASCADE
        )
      `);

      // 创建输出内容表
      await db.query(`
        CREATE TABLE IF NOT EXISTS ai_search_outputs (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL CHECK (type IN ('ppt', 'script', 'mindmap', 'other')),
          title TEXT NOT NULL,
          content TEXT NOT NULL,
          message_id TEXT NOT NULL,
          conversation_id TEXT NOT NULL,
          page_type TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (message_id) REFERENCES ai_search_messages(id) ON DELETE CASCADE,
          FOREIGN KEY (conversation_id) REFERENCES ai_search_conversations(id) ON DELETE CASCADE
        )
      `);
      
      // 如果表已存在但没有 page_type 字段，添加该字段
      try {
        await db.query(`ALTER TABLE ai_search_outputs ADD COLUMN page_type TEXT`);
      } catch (error: any) {
        // 如果字段已存在，忽略错误
        if (!error?.message?.includes('duplicate column') && !error?.message?.includes('already exists')) {
          logger.warn('添加 page_type 字段失败（可能已存在）', { error });
        }
      }

      // 创建索引
      await db.query(`
        CREATE INDEX IF NOT EXISTS idx_ai_search_messages_conversation_id 
        ON ai_search_messages(conversation_id)
      `);
      
      await db.query(`
        CREATE INDEX IF NOT EXISTS idx_ai_search_outputs_conversation_id 
        ON ai_search_outputs(conversation_id)
      `);
      
      await db.query(`
        CREATE INDEX IF NOT EXISTS idx_ai_search_outputs_message_id 
        ON ai_search_outputs(message_id)
      `);
      
      await db.query(`
        CREATE INDEX IF NOT EXISTS idx_ai_search_conversations_page_type 
        ON ai_search_conversations(page_type)
      `);
      
      await db.query(`
        CREATE INDEX IF NOT EXISTS idx_ai_search_outputs_page_type 
        ON ai_search_outputs(page_type)
      `);

      // 创建字段映射配置表
      await db.query(`
        CREATE TABLE IF NOT EXISTS ai_search_field_mappings (
          id TEXT PRIMARY KEY,
          workflow_id TEXT NOT NULL UNIQUE,
          config TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);
    } catch (error) {
      logger.error('初始化AI问答数据库表失败', { error });
      throw error;
    }
  }

  /**
   * 创建对话
   */
  async createConversation(title: string, sources: any[], pageType?: string): Promise<ConversationRecord> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    await db.query(
      `INSERT INTO ai_search_conversations (id, title, sources, page_type, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, title, JSON.stringify(sources), pageType || null, now, now]
    );

    return {
      id,
      title,
      sources: JSON.stringify(sources),
      page_type: pageType,
      created_at: now,
      updated_at: now,
    };
  }

  /**
   * 获取对话列表
   */
  async getConversations(pageType?: string): Promise<ConversationRecord[]> {
    try {
      let query = `SELECT * FROM ai_search_conversations`;
      const params: any[] = [];
      
      if (pageType) {
        query += ` WHERE page_type = ?`;
        params.push(pageType);
      }
      
      query += ` ORDER BY updated_at DESC`;
      
      const rows = await db.query(query, params) as any[];

      return rows.map((row) => ({
        id: row.id,
        title: row.title,
        sources: row.sources,
        page_type: row.page_type,
        created_at: row.created_at,
        updated_at: row.updated_at,
      }));
    } catch (error) {
      logger.error('获取对话列表失败', { error });
      // 如果表不存在，返回空数组
      return [];
    }
  }

  /**
   * 获取对话详情（包含消息）
   */
  async getConversation(
    id: string,
    options?: {
      limit?: number;
      before?: string;
    }
  ): Promise<any | null> {
    const conversationRows = await db.query(
      `SELECT * FROM ai_search_conversations WHERE id = ?`,
      [id]
    ) as any[];

    if (conversationRows.length === 0) {
      return null;
    }

    const conversation = conversationRows[0];

    const limit = options?.limit && Number.isFinite(options.limit)
      ? Math.min(Math.max(Number(options.limit), 1), 200)
      : undefined;
    const before = options?.before;

    const params: any[] = [id];
    let query = `
      SELECT * FROM ai_search_messages 
      WHERE conversation_id = ?
    `;

    if (before) {
      query += ` AND created_at < ?`;
      params.push(before);
    }

    query += ` ORDER BY created_at DESC`;

    if (limit) {
      query += ` LIMIT ?`;
      params.push(limit + 1);
    }

    const messageRows = await db.query(query, params) as any[];

    let hasMore = false;
    let nextCursor: string | null = null;

    if (limit && messageRows.length > limit) {
      hasMore = true;
      const lastRow = messageRows[messageRows.length - 1];
      nextCursor = lastRow.created_at;
      messageRows.pop();
    } else if (limit && messageRows.length === limit) {
      const oldestRow = messageRows[messageRows.length - 1];
      const countRows = await db.query(
        `SELECT COUNT(1) as total FROM ai_search_messages WHERE conversation_id = ? AND created_at < ?`,
        [id, oldestRow.created_at]
      ) as any[];
      const remaining = countRows?.[0]?.total || 0;
      hasMore = remaining > 0;
      nextCursor = hasMore ? oldestRow.created_at : null;
    }

    const messagesAsc = [...messageRows].reverse();

    return {
      id: conversation.id,
      title: conversation.title,
      sources: JSON.parse(conversation.sources || '[]'),
      messages: messagesAsc.map((row) => ({
        id: row.id,
        role: row.role,
        content: row.content,
        sources: row.sources ? JSON.parse(row.sources) : [],
        outputs: row.outputs ? JSON.parse(row.outputs) : {},
        createdAt: new Date(row.created_at),
      })),
      createdAt: new Date(conversation.created_at),
      updatedAt: new Date(conversation.updated_at),
      hasMoreMessages: hasMore,
      nextCursor,
    };
  }

  async getMessageById(id: string): Promise<MessageRecord | null> {
    const rows = await db.query(
      `SELECT * FROM ai_search_messages WHERE id = ?`,
      [id]
    ) as any[];

    if (rows.length === 0) {
      return null;
    }

    const row = rows[0];

    return {
      id: row.id,
      conversation_id: row.conversation_id,
      role: row.role,
      content: row.content,
      sources: row.sources,
      outputs: row.outputs,
      created_at: row.created_at,
    };
  }

  /**
   * 发送消息
   */
  async sendMessage(
    conversationId: string,
    role: 'user' | 'assistant',
    content: string,
    sources: any[] = [],
    files: any[] = [],
    outputs?: any // 输出字段（用于保存提取的工作流输出）
  ): Promise<MessageRecord> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    // 准备outputs字段（包含提取的输出字段）
    const outputsJson = outputs ? JSON.stringify(outputs) : null;
    
    await db.query(
      `INSERT INTO ai_search_messages (id, conversation_id, role, content, sources, outputs, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        conversationId,
        role,
        content,
        sources.length > 0 ? JSON.stringify(sources) : null,
        outputsJson,
        now,
      ]
    );

    // 更新对话的更新时间
    await db.query(
      `UPDATE ai_search_conversations SET updated_at = ? WHERE id = ?`,
      [now, conversationId]
    );

    return {
      id,
      conversation_id: conversationId,
      role,
      content,
      sources: sources.length > 0 ? JSON.stringify(sources) : undefined,
      outputs: outputsJson || undefined,
      created_at: now,
    };
  }

  /**
   * 删除对话
   */
  async deleteConversation(id: string): Promise<void> {
    await db.query(`DELETE FROM ai_search_conversations WHERE id = ?`, [id]);
  }

  /**
   * 生成输出内容
   */
  async generateOutput(
    type: 'ppt' | 'script' | 'mindmap' | 'other',
    conversationId: string,
    messageId: string,
    content: string,
    title?: string,
    pageType?: string
  ): Promise<OutputContentRecord> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const outputTitle = title || `${type}_${new Date().toISOString()}`;
    
    // 如果没有提供 pageType，尝试从对话中获取
    let finalPageType = pageType;
    if (!finalPageType) {
      const conversationRows = await db.query(
        `SELECT page_type FROM ai_search_conversations WHERE id = ?`,
        [conversationId]
      ) as any[];
      if (conversationRows.length > 0) {
        finalPageType = conversationRows[0].page_type;
      }
    }

    await db.query(
      `INSERT INTO ai_search_outputs 
       (id, type, title, content, message_id, conversation_id, page_type, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, type, outputTitle, JSON.stringify(content), messageId, conversationId, finalPageType || null, now]
    );

    // 更新消息的输出字段
    const messageRows = await db.query(
      `SELECT outputs FROM ai_search_messages WHERE id = ?`,
      [messageId]
    ) as any[];

    if (messageRows.length > 0) {
      const existingOutputs = messageRows[0].outputs 
        ? JSON.parse(messageRows[0].outputs) 
        : [];
      existingOutputs.push({
        id,
        type,
        title: outputTitle,
        content,
        createdAt: new Date(now),
      });

      await db.query(
        `UPDATE ai_search_messages 
         SET outputs = ? 
         WHERE id = ?`,
        [JSON.stringify(existingOutputs), messageId]
      );
    }

    return {
      id,
      type,
      title: outputTitle,
      content: JSON.stringify(content),
      message_id: messageId,
      conversation_id: conversationId,
      page_type: finalPageType,
      created_at: now,
    };
  }

  /**
   * 获取输出内容列表
   */
  async getOutputs(conversationId?: string, pageType?: string): Promise<OutputContentRecord[]> {
    let sql = `SELECT * FROM ai_search_outputs`;
    const params: any[] = [];
    const conditions: string[] = [];

    if (conversationId) {
      conditions.push(`conversation_id = ?`);
      params.push(conversationId);
    }
    
    if (pageType) {
      conditions.push(`page_type = ?`);
      params.push(pageType);
    }

    if (conditions.length > 0) {
      sql += ` WHERE ${conditions.join(' AND ')}`;
    }

    sql += ` ORDER BY created_at DESC`;

    try {
      const rows = await db.query(sql, params) as any[];

      return rows.map((row) => ({
        id: row.id,
        type: row.type,
        title: row.title,
        content: row.content,
        message_id: row.message_id,
        conversation_id: row.conversation_id,
        page_type: row.page_type,
        created_at: row.created_at,
      }));
    } catch (error) {
      logger.error('获取输出内容列表失败', { error });
      // 如果表不存在，返回空数组
      return [];
    }
  }
}

/**
 * 字段映射配置服务
 */
export class FieldMappingService {
  /**
   * 保存字段映射配置
   */
  async saveFieldMappingConfig(workflowId: string, config: FieldMappingConfigType): Promise<void> {
    try {
      const id = uuidv4();
      const now = new Date().toISOString();
      const configJson = JSON.stringify(config);

      // 检查是否已存在
      const existing = await db.query(
        `SELECT id FROM ai_search_field_mappings WHERE workflow_id = ?`,
        [workflowId]
      ) as any[];

      if (existing.length > 0) {
        // 更新
        await db.query(
          `UPDATE ai_search_field_mappings 
           SET config = ?, updated_at = ? 
           WHERE workflow_id = ?`,
          [configJson, now, workflowId]
        );
      } else {
        // 插入
        await db.query(
          `INSERT INTO ai_search_field_mappings (id, workflow_id, config, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?)`,
          [id, workflowId, configJson, now, now]
        );
      }
    } catch (error) {
      logger.error('保存字段映射配置失败', { error });
      throw error;
    }
  }

  /**
   * 获取字段映射配置
   */
  async getFieldMappingConfig(workflowId: string): Promise<FieldMappingConfigType | null> {
    try {
      const rows = await db.query(
        `SELECT config FROM ai_search_field_mappings WHERE workflow_id = ?`,
        [workflowId]
      ) as any[];

      if (rows.length === 0) {
        return null;
      }

      return JSON.parse(rows[0].config);
    } catch (error) {
      logger.error('获取字段映射配置失败', { error });
      return null;
    }
  }

  /**
   * 获取所有字段映射配置
   */
  async getAllFieldMappingConfigs(): Promise<Array<{ workflowId: string; config: FieldMappingConfigType; createdAt: string; updatedAt: string }>> {
    try {
      const rows = await db.query(
        `SELECT workflow_id, config, created_at, updated_at FROM ai_search_field_mappings ORDER BY updated_at DESC`
      ) as any[];

      return rows.map(row => ({
        workflowId: row.workflow_id,
        config: JSON.parse(row.config),
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (error) {
      logger.error('获取所有字段映射配置失败', { error });
      return [];
    }
  }

  /**
   * 删除字段映射配置
   */
  async deleteFieldMappingConfig(workflowId: string): Promise<void> {
    try {
      await db.query(
        `DELETE FROM ai_search_field_mappings WHERE workflow_id = ?`,
        [workflowId]
      );
    } catch (error) {
      logger.error('删除字段映射配置失败', { error });
      throw error;
    }
  }
}
